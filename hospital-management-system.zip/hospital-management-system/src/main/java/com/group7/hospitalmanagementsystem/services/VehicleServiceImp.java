package com.group7.hospitalmanagementsystem.services;


import com.group7.hospitalmanagementsystem.entity.VechileEntity;

import com.group7.hospitalmanagementsystem.model.Vechile;

import com.group7.hospitalmanagementsystem.repository.VechileRepository;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service

public class VehicleServiceImp implements VehicleService{
	
	private VechileRepository vechileRepository;

    public VehicleServiceImp(VechileRepository vechileRepository) {
        this.vechileRepository = vechileRepository;
    }

    @Override
    public Vechile createVechile(Vechile vechile) {
        VechileEntity vechileEntity = new VechileEntity();

        BeanUtils.copyProperties(vechile, vechileEntity);
        vechileRepository.save(vechileEntity);
        return vechile;
    }
//
//    @Override
//    public List<Vechile> getAllVechiles() {
//        List<VechileEntity> vechileEntities
//                = vechileRepository.findAll();
//       
//
//        List<Vechile> vechiles = vechileEntities
//                .stream()
//                .map(vec -> new Vechile(
//                		vec.getId(),
//                		vec.getRegistration_num(),
//                		vec.getMake(),
//                		vec.getModel(),
//                		vec.getType()))
//                .collect(Collectors.toList());
//        System.out.println(vechiles);
//        return vechiles;
//    }
//
//    @Override
//    public boolean deleteVechile(Long id) {
//        VechileEntity vechile = vechileRepository.findById(id).get();
//        vechileRepository.delete(vechile);
//        return true;
//    }
//
//    @Override
//    public Vechile getVechileById(Long id) {
//        VechileEntity vechileEntity
//                = vechileRepository.findById(id).get();
//        Vechile vechile = new Vechile();
//        BeanUtils.copyProperties(vechileEntity, vechile);
//        return vechile;
//    }

//    @Override
//    public Vechile updateVechile(Long id, Vechile vechile) {
//        VechileEntity vechileEntity
//                = vechileRepository.findById(id).get();
//        vechileEntity.setRegistration_num(vechile.getRegistration_num());
//        vechileEntity.setMake(vechile.getMake());
//        vechileEntity.setModel(vechile.getModel());
//        vechileEntity.setType(vechile.getType());
//
//        vechileRepository.save(vechileEntity);
//        return vechile;
//    }


}

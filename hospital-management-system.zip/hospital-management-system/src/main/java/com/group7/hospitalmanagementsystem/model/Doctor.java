package com.group7.hospitalmanagementsystem.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.group7.hospitalmanagementsystem.entity.EmployeeEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Doctor {

    private long docLicNum;
    private String name;
    private Date dob;
    private String contactInfo;
    private String degree;
	private long empId;
	
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Doctor(long docLicNum, String name, Date dob, String contactInfo, String degree, long empId) {
		this.docLicNum = docLicNum;
		this.name = name;
		this.dob = dob;
		this.contactInfo = contactInfo;
		this.degree = degree;
		this.empId = empId;
	}
	public long getDocLicNum() {
		return docLicNum;
	}
	public void setDocLicNum(long docLicNum) {
		this.docLicNum = docLicNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getContactInfo() {
		return contactInfo;
	}
	public void setContactInfo(String contactInfo) {
		this.contactInfo = contactInfo;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public long getEmpId() {
		return empId;
	}
	public void setEmpId(long empId) {
		this.empId = empId;
	}
	
	
	
	
}

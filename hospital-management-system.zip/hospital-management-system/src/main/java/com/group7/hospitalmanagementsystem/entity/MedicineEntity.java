package com.group7.hospitalmanagementsystem.entity;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

import javax.persistence.*;

@Entity

@Data
@Table(name = "medicine")
public class MedicineEntity {
	@Id
    private String medicineId;
    private String name;
    private Long price;
    private Long quantity;
    private String manufacturer;
    private Date manufacturedDate;
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="hospitalName")
    private HospitalEntity hospitalName;

    
	
    
}

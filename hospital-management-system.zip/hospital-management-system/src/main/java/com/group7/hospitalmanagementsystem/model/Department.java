package com.group7.hospitalmanagementsystem.model;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.group7.hospitalmanagementsystem.entity.EmployeeEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Department {
	
    private long deptId;
    private String deptName;
	private long headOfDept;	
	

}

package com.group7.hospitalmanagementsystem.entity;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity

@Data
@Table(name = "equipment")
public class EquipmentEntity {
	
	@Id
    private String equipmentId;
    private String make;
    private String model;
    private Long price;
    private Long quantity;
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="labId")
    private LabEntity labId;
    
	
    
    

}

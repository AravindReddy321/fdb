package com.group7.hospitalmanagementsystem.controller;


import com.group7.hospitalmanagementsystem.model.Doctor;
import com.group7.hospitalmanagementsystem.model.Employee;
import com.group7.hospitalmanagementsystem.model.Vechile;
import com.group7.hospitalmanagementsystem.services.DoctorService;
import com.group7.hospitalmanagementsystem.services.SystemService;
import com.group7.hospitalmanagementsystem.services.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@CrossOrigin
@RestController
@RequestMapping("/api/v1/")

public class systemcontroller {
	@Autowired
	private final SystemService systemService;
	private final VehicleService vehicleService;
	
	@Autowired
	private final DoctorService doctorService;
	
	public systemcontroller(SystemService systemService, VehicleService vehicleService,DoctorService doctorService) {
		this.systemService=systemService;
		this.vehicleService = vehicleService;
		this.doctorService=doctorService;
	}
	
	

//@PostMapping("/employees")
//public Employee createEmployee(@RequestBody Employee employee) {
//    return systemService.createEmployee(employee);
//}
//
//@GetMapping("/employees")
//public List<Employee> getAllEmployees() {
//    return  systemService.getAllEmployees();
//}
//
//@DeleteMapping("/employees/{id}")
//public ResponseEntity<Map<String,Boolean>> deleteEmployee(@PathVariable Long id) {
//    boolean deleted = false;
//    deleted = systemService.deleteEmployee(id);
//    Map<String,Boolean> response = new HashMap<>();
//    response.put("deleted", deleted);
//    return ResponseEntity.ok(response);
//}
//
//@GetMapping("/employees/{id}")
//public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id) {
//    Employee employee = null;
//    employee = systemService.getEmployeeById(id);
//    return ResponseEntity.ok(employee);
//}
//
//@PutMapping("/employees/{id}")
//public ResponseEntity<Employee> updateEmployee(@PathVariable Long id,
//                                               @RequestBody Employee employee) {
//    employee = systemService.updateEmployee(id, employee);
//    return ResponseEntity.ok(employee);
//}
//
////vehicles
//
//@PostMapping("/vechiles")
//public Vechile createEmployee(@RequestBody Vechile vechile) {
//    return vehicleService.createVechile(vechile);
//}
//
//@GetMapping("/vechiles")
//public List<Vechile> getAllVechiles() {
//    return  vehicleService.getAllVechiles();
//}
//
//@DeleteMapping("/vechiles/{id}")
//public ResponseEntity<Map<String,Boolean>> deleteVechile(@PathVariable Long id) {
//    boolean deleted = false;
//    deleted = vehicleService.deleteVechile(id);
//    Map<String,Boolean> response = new HashMap<>();
//    response.put("deleted", deleted);
//    return ResponseEntity.ok(response);
//}
//
//@GetMapping("/vechiles/{id}")
//public ResponseEntity<Vechile> getVechileById(@PathVariable Long id) {
//    Vechile vechile = null;
//    vechile = vehicleService.getVechileById(id);
//    return ResponseEntity.ok(vechile);
//}
//
//@PutMapping("/vechiles/{id}")
//public ResponseEntity<Vechile> updateVechile(@PathVariable Long id,
//                                               @RequestBody Vechile vechile) {
//    vechile = vehicleService.updateVechile(id, vechile);
//    return ResponseEntity.ok(vechile);
//}
	
	@PostMapping("/doctors")
	public Doctor addDoctor(@RequestBody Doctor doctor) {
	    return doctorService.addDoctor(doctor);
	}
	
	@GetMapping("/doctors")
	public List<Doctor> getAllDoctors() {
	    return  doctorService.getAllDoctors();
	}

}
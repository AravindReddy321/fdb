package com.group7.hospitalmanagementsystem.model;
import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.group7.hospitalmanagementsystem.entity.DriverEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Vechile {

	private String vehicleNumber;
    private String make;
    private String model;
    private String type;
    private String dLicNum;
    
    public Vechile() {
		// TODO Auto-generated constructor stub
	}

	public Vechile(String vehicleNumber, String make, String model, String type, String dLicNum) {
		this.vehicleNumber = vehicleNumber;
		this.make = make;
		this.model = model;
		this.type = type;
		this.dLicNum = dLicNum;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getdLicNum() {
		return dLicNum;
	}

	public void setdLicNum(String dLicNum) {
		this.dLicNum = dLicNum;
	}
    
    
}

package com.group7.hospitalmanagementsystem.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

import javax.persistence.*;

@Entity

@Data
@Table(name = "Bill")

public class BillEntity {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long billId;
	private long totalAmount;
	private float discount;
	private long finalAmount;
	private Date date;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="appointmentId")
	private AppointmentsEntity appointmentId;
	
	
	

}

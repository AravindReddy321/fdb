package com.group7.hospitalmanagementsystem.model;

import javax.persistence.CascadeType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.group7.hospitalmanagementsystem.entity.NurseEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Room {
	
    private String roomNum;
    private String type;
    private String availability;
	private long nurseId;

}

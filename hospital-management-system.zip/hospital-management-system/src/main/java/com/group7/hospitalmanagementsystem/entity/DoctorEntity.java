package com.group7.hospitalmanagementsystem.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

import javax.persistence.*;

@Entity

@Data
@Table(name = "doctor")
public class DoctorEntity {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long docLicNum;
    private String name;
    private Date dob;
    private String contactInfo;
    private String degree;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="empId")
	private EmployeeEntity empId;
	
	public DoctorEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DoctorEntity(long docLicNum, String name, Date dob, String contactInfo, String degree,
			EmployeeEntity empId) {
		super();
		this.docLicNum = docLicNum;
		this.name = name;
		this.dob = dob;
		this.contactInfo = contactInfo;
		this.degree = degree;
		this.empId = empId;
	}

	public long getDocLicNum() {
		return docLicNum;
	}

	public void setDocLicNum(long docLicNum) {
		this.docLicNum = docLicNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(String contactInfo) {
		this.contactInfo = contactInfo;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public EmployeeEntity getEmpId() {
		return empId;
	}

	public void setEmpId(EmployeeEntity empId) {
		this.empId = empId;
	}
	
	
    
	
   
}

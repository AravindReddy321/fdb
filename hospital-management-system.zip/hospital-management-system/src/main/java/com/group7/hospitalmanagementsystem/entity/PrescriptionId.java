package com.group7.hospitalmanagementsystem.entity;

import java.io.Serializable;

public class PrescriptionId implements Serializable{
	
	private long prescriptionId;
	private String medicineId;
	
	public PrescriptionId(long prescriptionId, String medicineId) {
		this.prescriptionId = prescriptionId;
		this.medicineId = medicineId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((medicineId == null) ? 0 : medicineId.hashCode());
		result = prime * result + (int) (prescriptionId ^ (prescriptionId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PrescriptionId other = (PrescriptionId) obj;
		if (medicineId == null) {
			if (other.medicineId != null)
				return false;
		} else if (!medicineId.equals(other.medicineId))
			return false;
		if (prescriptionId != other.prescriptionId)
			return false;
		return true;
	}

	
}

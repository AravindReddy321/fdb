package com.group7.hospitalmanagementsystem.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

import javax.persistence.*;

@Entity

@Data
@Table(name = "patient")

public class PatientEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long patientId;
    private String firstName;
    private String lastName;
    private Date dob;
    private String email;
    private String street;
    private String city;

}

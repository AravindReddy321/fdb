package com.group7.hospitalmanagementsystem.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity

@Data
@Table(name = "hospital")
public class HospitalEntity {
	
	@Id
    private String hospitalName;
    private String hospitalStreet;
    private String city;
    private String zipcode;
    private String contactInfo ;
    private String timings;
    
   

	
}

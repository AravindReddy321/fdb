package com.group7.hospitalmanagementsystem.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.group7.hospitalmanagementsystem.entity.HospitalEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Medicine {

	private String medicineId;
    private String name;
    private Long price;
    private Long quantity;
    private String manufacturer;
    private Date manufacturedDate;
    private String hospitalName;
    

    
    
	
}

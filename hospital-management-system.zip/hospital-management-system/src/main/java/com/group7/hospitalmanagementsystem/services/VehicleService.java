package com.group7.hospitalmanagementsystem.services;

import com.group7.hospitalmanagementsystem.model.Vechile;

import java.util.List;

public interface VehicleService {
	 Vechile createVechile(Vechile vechile);
//
//	    List<Vechile> getAllVechiles();
//
//	    boolean deleteVechile(Long id);
//
//	    Vechile getVechileById(Long id);
//
//	    Vechile updateVechile(Long id, Vechile vechile);

}

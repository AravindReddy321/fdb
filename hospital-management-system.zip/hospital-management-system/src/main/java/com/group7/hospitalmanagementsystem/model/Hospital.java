package com.group7.hospitalmanagementsystem.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Hospital {

    private String hospitalName;
    private String hospitalStreet;
    private String city;
    private String zipcode;
    private String contactInfo ;
    private String timings;
    
    
	
}

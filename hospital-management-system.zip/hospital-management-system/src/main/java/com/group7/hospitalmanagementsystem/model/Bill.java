package com.group7.hospitalmanagementsystem.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.group7.hospitalmanagementsystem.entity.AppointmentsEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Bill {

	    private long billId;
		private long totalAmount;
		private float discount;
		private long finalAmount;
		private Date date;
		private long appointmentId;
		
		
	
}

package com.group7.hospitalmanagementsystem.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

import javax.persistence.*;

@Entity

@Data
@Table(name = "nurse")
public class NurseEntity {
        @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private long nurseId;
	    private String name;
	    private Date dob;
	    private String qualification;
		@OneToOne(cascade=CascadeType.ALL)
		@JoinColumn(name="empId")
		private EmployeeEntity empId;
	    @ManyToOne(cascade=CascadeType.ALL)
	    @JoinColumn(name="reportingToDocLicNum")
	    private DoctorEntity docLicNum;
	    
	
		
	    
}

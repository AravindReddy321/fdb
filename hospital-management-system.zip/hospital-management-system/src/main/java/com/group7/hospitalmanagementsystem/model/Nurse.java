package com.group7.hospitalmanagementsystem.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.group7.hospitalmanagementsystem.entity.DoctorEntity;
import com.group7.hospitalmanagementsystem.entity.EmployeeEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Nurse {

    private long nurseId;
    private String name;
    private Date dob;
    private String qualification;
	private long empId;
    private String reportingToDocLicNum;
    
    
	
}

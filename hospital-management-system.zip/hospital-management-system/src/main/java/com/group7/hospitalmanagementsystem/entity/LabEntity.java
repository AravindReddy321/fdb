package com.group7.hospitalmanagementsystem.entity;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity

@Data
@Table(name = "labs")
public class LabEntity {
	
	@Id
    private String labId;
    private String labName;
    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="labInchargeId")
    private EmployeeEntity labInchargeId;
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="hospitalName")
    private HospitalEntity hospitalName;
    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="deptId")
    private DepartmentEntity deptId;

    
    
    

}

package com.group7.hospitalmanagementsystem.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity

@Data
@Table(name = "department")
public class DepartmentEntity {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long deptId;
    private String deptName;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="headOfDept")
	private EmployeeEntity emp;
	
	public DepartmentEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DepartmentEntity(long deptId, String deptName, EmployeeEntity emp) {
		super();
		this.deptId = deptId;
		this.deptName = deptName;
		this.emp = emp;
	}
	public long getDeptId() {
		return deptId;
	}
	public void setDeptId(long deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public EmployeeEntity getEmp() {
		return emp;
	}
	public void setEmp(EmployeeEntity emp) {
		this.emp = emp;
	}
	
	
    
	
}

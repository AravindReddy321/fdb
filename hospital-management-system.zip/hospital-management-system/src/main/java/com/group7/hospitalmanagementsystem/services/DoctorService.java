package com.group7.hospitalmanagementsystem.services;

import com.group7.hospitalmanagementsystem.model.Doctor;

import java.util.List;

public interface DoctorService {

	Doctor addDoctor(Doctor doctor);
	
	 List<Doctor> getAllDoctors();
	
}

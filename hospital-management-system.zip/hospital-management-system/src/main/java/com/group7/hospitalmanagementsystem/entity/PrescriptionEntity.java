package com.group7.hospitalmanagementsystem.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

import javax.persistence.*;

@Entity
@IdClass(PrescriptionId.class)
@Data
@Table(name = "prescription")

public class PrescriptionEntity {
	
	@Id
    private long prescriptionId;
	@Id
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="medicineId")
	private MedicineEntity medicineId;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="appointmentId")
	private AppointmentsEntity appointmentId;

}

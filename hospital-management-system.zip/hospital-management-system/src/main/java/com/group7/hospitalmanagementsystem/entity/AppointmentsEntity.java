package com.group7.hospitalmanagementsystem.entity;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

import javax.persistence.*;

@Entity

@Data
@Table(name = "appointments")


public class AppointmentsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long appointmentId;
	private Date appointmentDate;
    private String appointmentDesc;
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="patientId")
    private PatientEntity patientId;
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="docLicNum")
    private DoctorEntity docLicNum;
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="nurseId")
    private NurseEntity nurseId;
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="roomNum")
    private RoomEntity roomNum;
   
	
	
	
    

}

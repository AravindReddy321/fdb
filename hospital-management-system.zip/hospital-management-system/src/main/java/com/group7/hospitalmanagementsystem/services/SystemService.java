package com.group7.hospitalmanagementsystem.services;
import com.group7.hospitalmanagementsystem.model.Employee;
import com.group7.hospitalmanagementsystem.model.Vechile;

import java.util.List;


public interface SystemService {
	
	//employee services
	
//	Employee createEmployee(Employee employee);
//
//    List<Employee> getAllEmployees();
//
//    boolean deleteEmployee(Long id);
//
//    Employee getEmployeeById(Long id);
//
//    Employee updateEmployee(Long id, Employee employee);
    
    //vehicle services
    
   

	

}

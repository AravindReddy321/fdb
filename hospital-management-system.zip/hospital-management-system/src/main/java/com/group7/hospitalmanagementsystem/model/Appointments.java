package com.group7.hospitalmanagementsystem.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.group7.hospitalmanagementsystem.entity.DoctorEntity;
import com.group7.hospitalmanagementsystem.entity.PatientEntity;
import com.group7.hospitalmanagementsystem.entity.RoomEntity;
import com.group7.hospitalmanagementsystem.entity.VechileEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Appointments {
	
	private long appointmentId;
	private Date appointmentDate;
    private String appointmentDesc;
    private long patientId;
    private long docLicNum;
    private long nurseId;
    private String roomNum;
    
    

}

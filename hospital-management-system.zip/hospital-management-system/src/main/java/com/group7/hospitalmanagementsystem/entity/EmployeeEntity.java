package com.group7.hospitalmanagementsystem.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity

@Data
@Table(name = "employees")
public class EmployeeEntity {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String first_name;
    private String last_name;
    private String email;
    private String designation;
    private long experience;
    private long salary;
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="hospitalName")
    private HospitalEntity hospitalName;
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="deptId")
    private DepartmentEntity deptId;
    
	public EmployeeEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeEntity(long id, String first_name, String last_name, String email, String designation,
			long experience, long salary, HospitalEntity hospitalName, DepartmentEntity deptId) {
		super();
		this.id = id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.email = email;
		this.designation = designation;
		this.experience = experience;
		this.salary = salary;
		this.hospitalName = hospitalName;
		this.deptId = deptId;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public long getExperience() {
		return experience;
	}

	public void setExperience(long experience) {
		this.experience = experience;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public HospitalEntity getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(HospitalEntity hospitalName) {
		this.hospitalName = hospitalName;
	}

	public DepartmentEntity getDeptId() {
		return deptId;
	}

	public void setDeptId(DepartmentEntity deptId) {
		this.deptId = deptId;
	}
    
	
	
    

	
}

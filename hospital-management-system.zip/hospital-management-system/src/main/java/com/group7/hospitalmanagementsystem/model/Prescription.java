package com.group7.hospitalmanagementsystem.model;

import javax.persistence.CascadeType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.group7.hospitalmanagementsystem.entity.AppointmentsEntity;
import com.group7.hospitalmanagementsystem.entity.MedicineEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Prescription {
	

    private long prescriptionId;
	private String medicineId;
	private long appointmentId;

}

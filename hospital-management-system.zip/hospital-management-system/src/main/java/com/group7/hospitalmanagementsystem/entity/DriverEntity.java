package com.group7.hospitalmanagementsystem.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

import javax.persistence.*;

@Entity

@Data
@Table(name = "driver")
public class DriverEntity implements Serializable {
	
	
	@Id
	private String driverLicNum;
    private String name;
    private String dob;
    private String contact_info;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="empId")
	private EmployeeEntity empId;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="vehicleNum")
	private VechileEntity vehicleNum;
	
	public DriverEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DriverEntity(String driverLicNum, String name, String dob, String contact_info, EmployeeEntity empId,
			VechileEntity vehicleNum) {
		super();
		this.driverLicNum = driverLicNum;
		this.name = name;
		this.dob = dob;
		this.contact_info = contact_info;
		this.empId = empId;
		this.vehicleNum = vehicleNum;
	}

	public String getDriverLicNum() {
		return driverLicNum;
	}

	public void setDriverLicNum(String licNum) {
		this.driverLicNum = driverLicNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getContact_info() {
		return contact_info;
	}

	public void setContact_info(String contact_info) {
		this.contact_info = contact_info;
	}

	public EmployeeEntity getEmpId() {
		return empId;
	}

	public void setEmpId(EmployeeEntity empId) {
		this.empId = empId;
	}

	public VechileEntity getVehicleNum() {
		return vehicleNum;
	}

	public void setVehicleNum(VechileEntity vehicleNum) {
		this.vehicleNum = vehicleNum;
	}
	
	
	
 
    
}

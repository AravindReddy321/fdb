package com.group7.hospitalmanagementsystem.model;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.group7.hospitalmanagementsystem.entity.DepartmentEntity;
import com.group7.hospitalmanagementsystem.entity.EmployeeEntity;
import com.group7.hospitalmanagementsystem.entity.HospitalEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Lab {
	
    private String labId;
    private String labName;
    private long labInchargeId;
    private String hospitalName;
    private long deptId;
    
    
    
    

}

package com.group7.hospitalmanagementsystem.services;

import com.group7.hospitalmanagementsystem.entity.EmployeeEntity;
import com.group7.hospitalmanagementsystem.entity.VechileEntity;
import com.group7.hospitalmanagementsystem.model.Employee;
import com.group7.hospitalmanagementsystem.model.Vechile;
import com.group7.hospitalmanagementsystem.repository.EmployeeRepository;
import com.group7.hospitalmanagementsystem.repository.VechileRepository;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
@Service
public class SystemServiceImp implements SystemService{
	
//	private EmployeeRepository employeeRepository;
//
//    public SystemServiceImp(EmployeeRepository employeeRepository) {
//        this.employeeRepository = employeeRepository;
//    }
//
//    @Override
//    public Employee createEmployee(Employee employee) {
//        EmployeeEntity employeeEntity = new EmployeeEntity();
//
//        BeanUtils.copyProperties(employee, employeeEntity);
//        employeeRepository.save(employeeEntity);
//        return employee;
//    }
//
//    @Override
//    public List<Employee> getAllEmployees() {
//        List<EmployeeEntity> employeeEntities
//                = employeeRepository.findAll();
//       
//
//        List<Employee> employees = employeeEntities
//                .stream()
//                .map(vec -> new Employee(
//                		vec.getId(),
//                		vec.getFirst_name(),
//                		vec.getLast_name(),
//                		vec.getEmail(),
//                		vec.getDesignation()))
//                .collect(Collectors.toList());
//        System.out.println(employees);
//        return employees;
//    }
//
//    @Override
//    public boolean deleteEmployee(Long id) {
//        EmployeeEntity employee = employeeRepository.findById(id).get();
//        employeeRepository.delete(employee);
//        return true;
//    }
//
//    @Override
//    public Employee getEmployeeById(Long id) {
//        EmployeeEntity employeeEntity
//                = employeeRepository.findById(id).get();
//        Employee employee = new Employee();
//        BeanUtils.copyProperties(employeeEntity, employee);
//        return employee;
//    }

//    @Override
//    public Employee updateEmployee(Long id, Employee employee) {
//        EmployeeEntity employeeEntity
//                = employeeRepository.findById(id).get();
//        employeeEntity.setEmail(employee.getEmail());
//        employeeEntity.setFirst_name(employee.getFirst_name());
//        employeeEntity.setLast_name(employee.getLast_name());
//        employeeEntity.setDesignation(employee.getDesignation());
//
//        employeeRepository.save(employeeEntity);
//        return employee;
//    }

//    For Vechile below
    
    
    
}

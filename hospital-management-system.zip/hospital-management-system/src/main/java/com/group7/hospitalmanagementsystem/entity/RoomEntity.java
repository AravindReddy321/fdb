package com.group7.hospitalmanagementsystem.entity;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity

@Data
@Table(name = "rooms")


public class RoomEntity {
	
	@Id
    private String roomNum;
    private String type;
    private String availability;
    @OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="nurseId")
	private NurseEntity nurseId;
   

}

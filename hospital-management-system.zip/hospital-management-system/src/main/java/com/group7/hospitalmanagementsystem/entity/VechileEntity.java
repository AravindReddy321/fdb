package com.group7.hospitalmanagementsystem.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity

@Data
@Table(name = "vehicles")

public class VechileEntity {
	
	@Id
    private String vehicleNumber;
    private String make;
    private String model;
    private String type;
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="driverLicNum")
    private DriverEntity driverLicNum;
    
	

    
}

package com.group7.hospitalmanagementsystem.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.group7.hospitalmanagementsystem.entity.DoctorEntity;
import com.group7.hospitalmanagementsystem.model.Doctor;
import com.group7.hospitalmanagementsystem.repository.DoctorRepository;

@Service

public class DoctorServiceImp implements DoctorService {

	private DoctorRepository doctorRepository;

	public DoctorServiceImp(DoctorRepository doctorRepository) {
		this.doctorRepository = doctorRepository;
	}
	
  @Override
  public Doctor addDoctor(Doctor Doctor) {
      DoctorEntity DoctorEntity = new DoctorEntity();

      BeanUtils.copyProperties(Doctor, DoctorEntity);
      doctorRepository.save(DoctorEntity);
      return Doctor;
  }

  @Override
  public List<Doctor> getAllDoctors() {
      List<DoctorEntity> doctorEntities
              = doctorRepository.findAll();
     

      List<Doctor> doctors = doctorEntities
              .stream()
              .map(doc -> new Doctor(
            		doc.getDocLicNum(),
              		doc.getName(),
              		doc.getDob(),
              		doc.getContactInfo(),
              		doc.getDegree(),
              		doc.getEmpId().getId()))              
            		.collect(Collectors.toList());
      System.out.println(doctors);
      return doctors;
  }
	
	
	
}

package com.group7.hospitalmanagementsystem.model;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.group7.hospitalmanagementsystem.entity.LabEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Equipment {
	
    private String equipmentId;
    private String make;
    private String model;
    private Long price;
    private Long quantity;
    private String labId;
    
    
    

}
